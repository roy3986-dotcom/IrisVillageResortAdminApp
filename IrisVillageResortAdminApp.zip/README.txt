IRIS VILLAGE RESORT - ADMIN ANDROID APP

This project wraps:
https://irisvillageresort.in/admin/login.php

App name: Iris Village Resort
Application ID: in.irisvillageresort.admin
The supplied Iris logo is used as the launcher icon.

Build:
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build APK(s).

The app requires internet access and keeps the admin site inside a WebView.
Android Back navigates inside the site before closing the app.
