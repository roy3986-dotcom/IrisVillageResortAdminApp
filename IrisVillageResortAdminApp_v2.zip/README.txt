IRIS VILLAGE RESORT - ADMIN ANDROID APP v2

Wraps:
https://irisvillageresort.in/admin/login.php

Application ID: in.irisvillageresort.admin
Version: 2.0

Features:
- Iris Village Resort splash screen with supplied logo
- Loading indicator
- Android Back button navigates WebView history
- Pull down to refresh
- Internet connection check and Retry dialog
- Admin website/backend remains unchanged

Build:
Open in Android Studio and build the debug APK.
